import React, { useEffect, useState } from "react";
import { Check, X, UserCog } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function DriverDashboard() {
  const [bookings, setBookings] = useState([]);
  const [activeTab, setActiveTab] = useState("accept-ride");
  const [notification, setNotification] = useState(null);
  const [confirmPopup, setConfirmPopup] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const driverEmail = localStorage.getItem("driver_email");

  // ✅ Profile form state
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    address: "",
    licenseNumber: "",
    vehicleType: "",
    vehicleNumber: "",
    experience: "",
    languages: [],
    emergencyContact: "",
    emergencyPhone: "",
    availability: "",
    icPhoto: null,
    selfiePhoto: null,
    licensePhoto: null,
    vehiclePhoto: null,
  });

  useEffect(() => {
    if (!driverEmail) navigate("/driver-login");
  }, [driverEmail, navigate]);

  // Fetch bookings
  const fetchBookings = async () => {
    try {
      const res = await fetch("http://localhost/backend/getAllBooking.php");
      const data = await res.json();
      setBookings(data);
    } catch (err) {
      console.error(err);
      setNotification("⚠️ Failed to load bookings.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === "accept-ride") fetchBookings();
  }, [activeTab]);

  // Confirm and handle accept
  const confirmAccept = (booking) => setConfirmPopup(booking);

  const handleAccept = async (booking) => {
    setConfirmPopup(null);
    if (!navigator.geolocation)
      return setNotification("⚠️ Geolocation not supported.");

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        try {
          const response = await fetch("http://localhost/backend/acceptBooking.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              ride_id: booking.ride_id,
              passenger_email: booking.email,
              date: booking.date,
              time: booking.time,
              driver_email: driverEmail,
              latitude,
              longitude,
            }),
          });
          const result = await response.json();
          if (result.success) {
            setBookings((prev) =>
              prev.filter((b) => b.ride_id !== booking.ride_id)
            );
            setNotification("✅ Booking accepted successfully!");
          } else setNotification("❌ " + (result.message || "Update failed"));
        } catch {
          setNotification("⚠️ Something went wrong.");
        } finally {
          setTimeout(() => setNotification(null), 3000);
        }
      },
      () => setNotification("⚠️ Unable to get location.")
    );
  };

  const getCurrentAddress = async () => {
    if (!navigator.geolocation) return alert("Geolocation not supported.");
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude, longitude } = pos.coords;
      const res = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=YOUR_GOOGLE_MAPS_API_KEY`
      );
      const data = await res.json();
      if (data.results?.length) {
        setFormData((prev) => ({
          ...prev,
          address: data.results[0].formatted_address,
        }));
      } else alert("Unable to detect address.");
    });
  };

  // Handle inputs
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setFormData((prev) => ({
        ...prev,
        languages: checked
          ? [...prev.languages, value]
          : prev.languages.filter((l) => l !== value),
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleImageChange = (e) => {
    const { name, files } = e.target;
    if (files && files[0]) {
      setFormData((prev) => ({ ...prev, [name]: files[0] }));
    }
  };

  const handleProfileSubmit = (e) => {
    e.preventDefault();
    console.log("Driver profile submitted:", formData);
    alert("✅ Profile setup saved successfully!");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex flex-col">
      {/* Header */}
      <header className="bg-blue-700 text-white px-6 py-4 flex flex-wrap justify-between items-center shadow-md">
        <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
          🚗 Driver Dashboard
        </h1>
        <div className="flex gap-2 mt-2 sm:mt-0">
          <button
            className="bg-white text-blue-700 px-4 py-2 rounded-lg hover:bg-gray-100 font-semibold"
            onClick={() => navigate("/home")}
          >
            Home
          </button>
          <button
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 font-semibold"
            onClick={() => {
              localStorage.removeItem("driver_email");
              navigate("/driver-login");
            }}
          >
            Logout
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="flex flex-wrap justify-center mt-5 gap-3 px-4">
        <button
          onClick={() => setActiveTab("accept-ride")}
          className={`flex-1 sm:flex-none min-w-[140px] text-center px-5 py-2 rounded-lg font-medium shadow-sm ${
            activeTab === "accept-ride"
              ? "bg-blue-600 text-white"
              : "bg-gray-200 text-gray-700"
          }`}
        >
          🚘 Accept Ride
        </button>
        <button
          onClick={() => setActiveTab("setup-profile")}
          className={`flex-1 sm:flex-none min-w-[140px] text-center px-5 py-2 rounded-lg font-medium flex items-center justify-center gap-2 shadow-sm ${
            activeTab === "setup-profile"
              ? "bg-green-600 text-white"
              : "bg-gray-200 text-gray-700"
          }`}
        >
          <UserCog size={18} /> Setup Profile
        </button>
      </div>

      {/* Notification */}
      {notification && (
        <div className="fixed top-20 right-4 bg-white border shadow-lg px-6 py-3 rounded-lg text-gray-800 z-30">
          {notification}
        </div>
      )}

      {/* Confirm Popup */}
      {confirmPopup && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-2xl shadow-lg w-[90%] sm:w-96">
            <h2 className="text-lg font-semibold mb-4 text-gray-800">
              Confirm Ride Acceptance
            </h2>
            <p className="mb-4 text-gray-600">
              Accept booking for{" "}
              <span className="font-semibold">{confirmPopup.name}</span>?
            </p>
            <div className="flex justify-end gap-3">
              <button
                className="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300"
                onClick={() => setConfirmPopup(null)}
              >
                <X size={16} /> Cancel
              </button>
              <button
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                onClick={() => handleAccept(confirmPopup)}
              >
                <Check size={16} /> Accept
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <main className="flex-1 p-4 sm:p-6">
        {activeTab === "accept-ride" ? (
          loading ? (
            <p className="text-center text-gray-500 mt-10">
              Loading bookings...
            </p>
          ) : bookings.length > 0 ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {bookings.map((booking, i) => (
                <div
                  key={i}
                  className="bg-white rounded-2xl shadow-md p-5 border hover:shadow-lg transition"
                >
                  <h2 className="text-lg font-semibold">{booking.name}</h2>
                  <p className="text-sm text-gray-500">{booking.email}</p>
                  <p className="mt-2 text-gray-700">
                    📅 {booking.date} | 🕒 {booking.time}
                  </p>
                  <p className="text-blue-600 font-medium mt-1">
                    {booking.pickup} → {booking.destination}
                  </p>
                  <button
                    onClick={() => confirmAccept(booking)}
                    className="mt-4 w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 flex items-center justify-center gap-2"
                  >
                    <Check size={16} /> Accept Ride
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 mt-10">
              No bookings available
            </p>
          )
        ) : (
          <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold mb-4 text-gray-800">
              Driver Profile Setup
            </h2>
            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-3">
                <input
                  name="name"
                  placeholder="Full Name"
                  onChange={handleChange}
                  required
                  className="p-3 border rounded-lg"
                />
                <input
                  name="phone"
                  placeholder="Phone Number"
                  onChange={handleChange}
                  required
                  className="p-3 border rounded-lg"
                />
              </div>
              <input
                name="licenseNumber"
                placeholder="License Number"
                onChange={handleChange}
                required
                className="w-full p-3 border rounded-lg"
              />
              <div className="grid sm:grid-cols-2 gap-3">
                <input
                  name="vehicleType"
                  placeholder="Vehicle Type"
                  onChange={handleChange}
                  required
                  className="p-3 border rounded-lg"
                />
                <input
                  name="vehicleNumber"
                  placeholder="Vehicle Number"
                  onChange={handleChange}
                  required
                  className="p-3 border rounded-lg"
                />
              </div>
              <input
                name="experience"
                placeholder="Years of Experience"
                onChange={handleChange}
                required
                className="w-full p-3 border rounded-lg"
              />

              {/* Languages */}
              <div>
                <label className="block font-medium mb-1">
                  Languages Spoken:
                </label>
                <div className="flex flex-wrap gap-3">
                  {["English", "Malay", "Chinese", "Tamil", "Arabic"].map(
                    (lang) => (
                      <label
                        key={lang}
                        className="flex items-center gap-2 text-gray-700"
                      >
                        <input
                          type="checkbox"
                          value={lang}
                          onChange={handleChange}
                        />{" "}
                        {lang}
                      </label>
                    )
                  )}
                </div>
              </div>

              <textarea
                name="address"
                placeholder="Address"
                onChange={handleChange}
                rows={3}
                required
                className="w-full p-3 border rounded-lg"
              ></textarea>
              <button
                type="button"
                onClick={getCurrentAddress}
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
              >
                📍 Use My Location
              </button>

              <div className="grid sm:grid-cols-2 gap-3">
                <input
                  name="emergencyContact"
                  placeholder="Emergency Contact Name"
                  onChange={handleChange}
                  required
                  className="p-3 border rounded-lg"
                />
                <input
                  name="emergencyPhone"
                  placeholder="Emergency Contact Number"
                  onChange={handleChange}
                  required
                  className="p-3 border rounded-lg"
                />
              </div>

              <select
                name="availability"
                onChange={handleChange}
                required
                className="w-full p-3 border rounded-lg"
              >
                <option value="">Select Availability</option>
                <option value="Full Time">Full Time</option>
                <option value="Part Time">Part Time</option>
                <option value="Flexible">Flexible</option>
              </select>

              {/* Image Uploads */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  { name: "icPhoto", label: "IC Photo" },
                  { name: "selfiePhoto", label: "Selfie Photo" },
                  { name: "licensePhoto", label: "License Photo" },
                  { name: "vehiclePhoto", label: "Vehicle Photo" },
                ].map((item) => (
                  <div key={item.name}>
                    <label className="font-medium block mb-1">
                      {item.label}
                    </label>
                    <input
                      type="file"
                      name={item.name}
                      accept="image/*"
                      onChange={handleImageChange}
                      className="w-full p-2 border rounded-lg"
                    />
                    {formData[item.name] && (
                      <img
                        src={URL.createObjectURL(formData[item.name])}
                        alt={item.label}
                        className="mt-2 rounded-lg w-full h-32 object-cover border"
                      />
                    )}
                  </div>
                ))}
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-semibold"
              >
                💾 Save Profile
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}
